To run Open Project 1 VI folder and run Project 1 VI
In Visual Studio open the Source Files folder and click on Main.cpp then press Ctrl + F5

Editor:
j = moves down 1 row
k = moves up 1 row
h = moves left 1 column
l = moves right 1 column
x = deletes current character
d d = deletes current row
i = enters insert mode allows user to insert text
u = undo