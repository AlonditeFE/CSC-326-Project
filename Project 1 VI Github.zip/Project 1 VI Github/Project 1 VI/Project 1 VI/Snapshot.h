#pragma once
#include "point.h"
#include <string>
#include <fstream>
#include "conio.h"
class Snapshot
{
public:
	Snapshot();
	Snapshot(char, Point<int>,string);
	char setCommand(char);
	Point<int> setPositon(Point<int>);
	string setValue(string);
	char getCommand();
	Point<int> getPositon();
	string getValue();

private:
	char command;
	Point<int> position;
	string value;

};