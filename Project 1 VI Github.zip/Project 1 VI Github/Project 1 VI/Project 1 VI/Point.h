#pragma once
//Header file of Point.inl
template <class TYPE>
class Point {
public:
	Point();
	Point(TYPE, TYPE);
	void display();

	TYPE getX() const;
	TYPE getY() const;
	Point operator - (const Point&) const;
	Point operator + (const Point&) const;
private:
	TYPE mX;
	TYPE mY;
};
#include "Point.inl"