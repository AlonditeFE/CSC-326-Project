/*Creates a VI that allows users to move the cursor and remove lines*/
#include "Editor.h"

void main()
{
	Editor xEditor;
	xEditor.readfile("sample.txt");
	xEditor.run();
	//system("PAUSE");
	return;
}