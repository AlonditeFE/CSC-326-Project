#include "Point.h"
#include <iostream>

using namespace std;


void main() {
	Point<int> p1(1, 2);
	Point <double> p2(7.1, 3.5);

	p1.display();
	p2.display();
	cout << endl;


}