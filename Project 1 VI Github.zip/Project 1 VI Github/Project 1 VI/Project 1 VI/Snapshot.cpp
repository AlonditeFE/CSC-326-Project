#include "Snapshot.h"
Snapshot::Snapshot()
{

}
Snapshot::Snapshot(char savedCommand, Point<int> savedPosition, string savedValue)
{
	command = savedCommand;
	position = savedPosition;
	value = savedValue;
}
char Snapshot::setCommand(char savedCommand)
{
	command = savedCommand;
	return command;
}
Point<int> Snapshot::setPositon(Point<int> savedPosition)
{
	position = savedPosition;
	return position;
}
string Snapshot::setValue(string savedValue)
{
	value = savedValue;
	return value;
}
char Snapshot::getCommand()
{
	return command;
}
Point<int> Snapshot::getPositon()
{
	return position;
}
string Snapshot::getValue()
{
	return value;
}