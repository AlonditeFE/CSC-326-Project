#pragma once
#include "LinkedList.h"
#include "point.h"
#include "Node.h"
#include <string>
#include <stack>
#include "Snapshot.h"
#include "BinarySearchTree.h"
using namespace std;
class Editor
{
public:
	bool readfile(string filename);
	void run();
	void display();
	void insertDisplay(int count);
	void displayTill(int end);

private:
	LinkedList<string> lines;
	stack<Snapshot> undo;
	Point<int>position = Point<int>(0,0);
	BinarySearchTree<string> keywordsBST;
};
#include"Editor.inl"